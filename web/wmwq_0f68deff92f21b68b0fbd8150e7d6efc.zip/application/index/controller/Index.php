<?php
namespace app\index\controller;

class Index
{
    public function index()
    {
        return '<form method="post" enctype="multipart/form-data" action='.url('index/index/upload').'>
            <input type="file" name="hw_file">
            <input type="submit" value="上传">';

    }

    public function upload()
    {
        if (request()->isPost()){
            $file = $_FILES['hw_file']?$_FILES['hw_file']:'';
            if(!$file){
                return json(['code'=>0,'msg'=>'请选择文件']);
            }
            $file_name = $file['name'];
            $file_tmp = $file['tmp_name'];
            $content = file_get_contents($file_tmp);
            if (strstr($content, "<")) {
                return 0;
            }
            $file_size = $file['size'];
            if ($file_size > 1024*1024*2){
                return json(['code'=>0,'msg'=>'文件大小不能超过2M']);
            }
            $file_error = $file['error'];
            if ($file_error > 0){
                return json(['code'=>0,'msg'=>'上传失败']);
            }
            $file_type = $file['type'];
            $file_ext = explode('.',$file_name);
            $file_ext = strtolower(end($file_ext));
            if(strstr($file_type, "image/")){
                if($this->upload_as_image($file_ext, $file_tmp, "../uploads/images/".date('YmdHis')."/", ["gif"], request()->get("hw_file_name")?request()->get("hw_file_name"):FALSE)){
                    return json(['code'=>1,'msg'=>'上传成功']);
                } else {
                    return json(['code'=>0,'msg'=>'上传失败']);
                }
            } else {
                if($this->upload_as_text($file_ext, $file_tmp, "../uploads/files/".date('YmdHis')."/", request()->get("hw_file_name")?request()->get("hw_file_name"):FALSE)){
                    return json(['code'=>1,'msg'=>'上传成功']);
                } else {
                    return json(['code'=>0,'msg'=>'上传失败']);
                }
            }
        } else {
            return json(['code'=>0,'msg'=>'请求方式错误']);
        } 
    }

    public function upload_as_image($image_type, $image_tmp_file, $upload_base_dir, $file_ext_black_list, $image_filename=FALSE)
    {
        if(in_array($image_type, $file_ext_black_list)){
            return 0;
        }
        switch ($image_type) {
            case 'jpg':
                $image_ext = '.jpg';
                break;
            case 'png':
                $image_ext = '.png';
                break;
            case 'gif':
                $image_ext = '.gif';
                break;
            default:
                $image_ext = '.jpg';
                break;
        }
        $image_size = getimagesize($image_tmp_file);
        $image_width = $image_size[0];
        $image_height = $image_size[1];
        if($image_width > 200 || $image_height > 200){
            return 0;
        }
        if ($image_filename === FALSE) {
            $image_filename = date('YmdHis') . rand(1000, 9999) . $image_ext;
        } else {
            $image_filename = $image_filename . $image_ext;
        }
        if(!file_exists($upload_base_dir)){
            mkdir($upload_base_dir, 0777, true);
        }
        $image_file_path = $upload_base_dir . $image_filename;
        rename($image_tmp_file, $image_file_path);
        return 1;
    }

    public function upload_as_text($text_type, $text_tmp_file, $upload_base_dir, $text_filename=FALSE)
    {
        if(strstr($text_type, "ph")  || in_array($text_type, ['php', 'html', 'js', 'css', 'sql', 'phtml', 'shtml', 'php5', 'php7', 'phtm', 'pht', 'php8', 'php4', 'htaccess', 'tpl', 'ini'])){
            return 0;
        }
        if (strstr($text_filename, ".") || strstr($text_filename, "/")) {
            return 0;
        }
        if( strlen($text_type) == 0){
            $text_ext = "";
        } else {
            if(!ctype_alpha($text_type)){
                return 0;
            }
            $text_ext = "." . $text_type;
        }
        if ($text_filename === FALSE) {
            $text_filename = date('YmdHis') . rand(1000, 9999) . $text_ext;
        } else {
            $text_filename = $text_filename . $text_ext;
        }
        if(strlen($text_filename) == 0 || strstr($text_filename, "/") ||!preg_match('/[A-Za-z0-9_]/is', $text_filename)){
            return 0;
        }
        if(!file_exists($upload_base_dir)){
            mkdir($upload_base_dir, 0777, true);
        }
        $text_file_path = $upload_base_dir . "/" . $text_filename;
        rename($text_tmp_file, $text_file_path);
        return 1;
    }
}
