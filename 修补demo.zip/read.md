# 打包tar.gz

Linux打包tar.gz 文件命令

```bash
tar zcvf update.tar.gz update.sh file1 file2
```

![image-20220719125636278](img/image-20220719125636278.png)

![image-20220719125708170](img/image-20220719125708170.png)

* update.sh 里面为修补时需要执行的命令

  ![image-20220719125955640](img/image-20220719125955640.png)