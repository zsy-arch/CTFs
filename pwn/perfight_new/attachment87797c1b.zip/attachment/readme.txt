Free memory corruption is given to you! Can you escape the v8 powerful sandbox?
