import subprocess
import sys
import tempfile

def check(script):
    with tempfile.NamedTemporaryFile(mode="w+") as fp:
        fp.write(script)
        fp.seek(0)
        result = subprocess.run(f"/d8 {fp.name}", shell=True, capture_output=True)
        stdout = result.stdout.decode("utf-8")
        for i in range(8):
            sys.stderr.write(stdout)

def server():
    script = ""
    for line in sys.stdin:
        if "EOF" in line:
            break
        script += line
    check(script)

if __name__ == "__main__":
    server()
